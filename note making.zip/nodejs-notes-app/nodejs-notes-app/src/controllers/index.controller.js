export const renderIndex = (req, res) => {
  res.render("index");
};

export const renderAbout = (req, res) => {
  res.render("about");
};

export const renderSnake = (req, res) => {
  res.render("snake");
};
export const renderport = (req, res) => {
  res.render("portfolio");
};
