import { Router } from "express";
import { renderIndex, renderAbout,renderSnake } from "../controllers/index.controller.js";

const router = Router();

router.get("/", renderIndex);
router.get("/about", renderAbout);
router.get("/snake", renderSnake);
router.get("/portfolio", renderSnake);

export default router;
